/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sleeptrackerapp;

/**
 *
 * @author WALEED TRADERS
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalTime;

public class SleepTrackerApp {
    private JFrame mainFrame;
    private JPanel homePanel;
    private JPanel signInPanel;
    private JPanel signUpPanel;
    private JPanel sleepTrackingPanel;
    private JTextField usernameField;
    private JPasswordField passwordField;

    private String authorizedUsername = ""; // Authorized username
    private String authorizedPassword = ""; // Authorized password

    private boolean isDarkMode = false; // Track dark mode state

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SleepTrackerApp();
            }
        });
    }

    public SleepTrackerApp() {
        // Create the main frame
        mainFrame = new JFrame("Sleep Tracker App");
        mainFrame.setSize(800, 600);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLayout(new BorderLayout());

        // Create sign in and sign up panels
        signInPanel = createSignInPanel();
        signUpPanel = createSignUpPanel();

        // Add sign in panel to the main frame
        mainFrame.add(signInPanel, BorderLayout.CENTER);

        // Set the main frame visible
        mainFrame.setVisible(true);
    }

    private JPanel createSignInPanel() {
        JPanel panel = new JPanel(new GridLayout(4, 1));
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("Sign In");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel fieldsPanel = new JPanel(new GridLayout(2, 2));
        fieldsPanel.setBackground(Color.WHITE);

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();

        fieldsPanel.add(usernameLabel);
        fieldsPanel.add(usernameField);
        fieldsPanel.add(passwordLabel);
        fieldsPanel.add(passwordField);

        JButton signInButton = new JButton("Sign In");
        signInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                signIn();
            }
        });

        JButton signUpButton = new JButton("Sign Up");
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToSignUpPanel();
            }
        });

        panel.add(titleLabel);
        panel.add(fieldsPanel);
        panel.add(signInButton);
        panel.add(signUpButton);

        return panel;
    }

    private JPanel createSignUpPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 1));
        panel.setBackground(Color.WHITE);

        JLabel titleLabel = new JLabel("Sign Up");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel fieldsPanel = new JPanel(new GridLayout(2, 2));
        fieldsPanel.setBackground(Color.WHITE);

        JLabel usernameLabel = new JLabel("Username:");
        JTextField newUsernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField newPasswordField = new JPasswordField();

        fieldsPanel.add(usernameLabel);
        fieldsPanel.add(newUsernameField);
        fieldsPanel.add(passwordLabel);
        fieldsPanel.add(newPasswordField);

        JButton signUpButton = new JButton("Sign Up");
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                signUp(newUsernameField.getText(), new String(newPasswordField.getPassword()));
            }
        });

        JButton backButton = new JButton("Back to Sign In");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToSignInPanel();
            }
        });

        panel.add(titleLabel);
        panel.add(fieldsPanel);
        panel.add(signUpButton);
        panel.add(backButton);

        return panel;
    }

    private void signIn() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.equals(authorizedUsername) && password.equals(authorizedPassword)) {
            // Successful sign-in
            JOptionPane.showMessageDialog(mainFrame, "Successfully signed in as: " + username);
            openHomeFrame();
        } else {
            // Incorrect username or password
            JOptionPane.showMessageDialog(mainFrame, "Incorrect username or password. Please try again.");
        }
    }

    private void signUp(String username, String password) {
        // Implement logic for signing up
        // Example: Create new user account
        authorizedUsername = username;
        authorizedPassword = password;
        JOptionPane.showMessageDialog(mainFrame, "Account created successfully!");
        switchToSignInPanel();
    }

    private void switchToSignUpPanel() {
        mainFrame.getContentPane().remove(signInPanel);
        mainFrame.add(signUpPanel, BorderLayout.CENTER);
        mainFrame.revalidate();
        mainFrame.repaint();
    }

    private void switchToSignInPanel() {
        mainFrame.getContentPane().remove(signUpPanel);
        mainFrame.add(signInPanel, BorderLayout.CENTER);
        mainFrame.revalidate();
        mainFrame.repaint();
    }

    private void openHomeFrame() {
        homePanel = new JPanel(new BorderLayout());
        setPanelBackground(homePanel);

        // Top left corner - More Options button with text
        JButton moreOptionsButton = new JButton("More Options");
         moreOptionsButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            openMoreOptionsFrame();
        }
    });
    homePanel.add(moreOptionsButton, BorderLayout.NORTH);

        homePanel.add(moreOptionsButton, BorderLayout.NORTH);

        // Center - Date, Time, Sleep Time, Weekly Average, Last Week Average
        JPanel centerPanel = new JPanel(new GridLayout(5, 1));
        setPanelBackground(centerPanel);

        JLabel dateLabel = new JLabel("Date: " + LocalDate.now());
        JLabel timeLabel = new JLabel("Time: " + LocalTime.now());
        JLabel sleepTimeLabel = new JLabel("Sleep Time: 3am to 6pm"); // Example sleep time
        JLabel weeklyAverageLabel = new JLabel("Weekly Average Sleep: 7 hours"); // Example weekly average
        JLabel lastWeekAverageLabel = new JLabel("Last Week Average Sleep: 6.5 hours"); // Example last week average

        centerPanel.add(dateLabel);
        centerPanel.add(timeLabel);
        centerPanel.add(sleepTimeLabel);
        centerPanel.add(weeklyAverageLabel);
        centerPanel.add(lastWeekAverageLabel);
        homePanel.add(centerPanel, BorderLayout.CENTER);

        // Bottom - Start Tracking button and Music/Podcast/Breath buttons
        JButton startTrackingButton = new JButton("Start Tracking");
        startTrackingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openSleepTrackingFrame();
            }
        });
        JButton musicButton = new JButton("Music");
        musicButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            // Open YouTube music in the default web browser
            Desktop.getDesktop().browse(new URI("https://music.youtube.com/"));
        } catch (Exception ex) {
            ex.printStackTrace();
            // Handle any exceptions
        }
    }
});
        JButton podcastButton = new JButton("Podcast");
        podcastButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Implement action to show fitness, gym, and sleep podcasts
            openFitnessPodcasts();
            
        }
    });
           JButton     breathButton = new JButton("Breath 1 Min");
breathButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            openBreathTimerFrame(); // Call the function to open the breath timer frame
        }
    });
        JPanel bottomPanel = new JPanel(new GridLayout(2, 1));
        setPanelBackground(bottomPanel);

        JPanel buttonsPanel = new JPanel(new GridLayout(1, 3));
        buttonsPanel.add(musicButton);
        buttonsPanel.add(podcastButton);
        buttonsPanel.add(breathButton);
        bottomPanel.add(startTrackingButton);
        bottomPanel.add(buttonsPanel);
        homePanel.add(bottomPanel, BorderLayout.SOUTH);

        // Add home panel to main frame
        mainFrame.getContentPane().removeAll();
        mainFrame.add(homePanel);
        mainFrame.revalidate();
        mainFrame.repaint();
    }

private JPanel createSleepTrackingPanel() {
    JPanel panel = new JPanel(new BorderLayout());

    // Good Night label
    JLabel goodNightLabel = new JLabel("Good Night");
    goodNightLabel.setFont(new Font("Arial", Font.BOLD, 24));
    goodNightLabel.setHorizontalAlignment(SwingConstants.CENTER);
    panel.add(goodNightLabel, BorderLayout.NORTH);

    // Timer for sleep duration
    JLabel sleepDurationLabel = new JLabel("Sleep Duration: ");
    panel.add(sleepDurationLabel, BorderLayout.CENTER);
    Timer timer = new Timer(1000, new ActionListener() {
        int hours = 0;
        int minutes = 0;
        int seconds = 0;

        @Override
        public void actionPerformed(ActionEvent e) {
            seconds++;
            if (seconds == 60) {
                seconds = 0;
                minutes++;
            }
            if (minutes == 60) {
                minutes = 0;
                hours++;
            }
            sleepDurationLabel.setText("Sleep Duration: " + String.format("%02d:%02d:%02d", hours, minutes, seconds));
        }
    });
    timer.start();

    // Alarm at time select
    JPanel alarmPanel = new JPanel();
    JLabel alarmLabel = new JLabel("Set Alarm:");
    JTextField alarmTimeField = new JTextField(8);
    JComboBox<String> amPmComboBox = new JComboBox<>(new String[]{"AM", "PM"});
    JButton setAlarmButton = new JButton("Set");
    setAlarmButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String alarmTime = alarmTimeField.getText() + " " + amPmComboBox.getSelectedItem();
            // Implement logic to set the alarm
            JOptionPane.showMessageDialog(mainFrame, "Alarm set for: " + alarmTime);
        }
    });
    alarmPanel.add(alarmLabel);
    alarmPanel.add(alarmTimeField);
    alarmPanel.add(amPmComboBox);
    alarmPanel.add(setAlarmButton);
    panel.add(alarmPanel, BorderLayout.CENTER);

    // Stop Tracking button
    JButton stopTrackingButton = new JButton("Stop Tracking");
    stopTrackingButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            stopSleepTracking();
            timer.stop(); // Stop the timer when tracking is stopped
        }
    });
    panel.add(stopTrackingButton, BorderLayout.SOUTH);

    return panel;
}

private void openSleepTrackingFrame() {
    sleepTrackingPanel = createSleepTrackingPanel();

    // Add sleep tracking panel to main frame
    mainFrame.getContentPane().removeAll();
    mainFrame.add(sleepTrackingPanel);
    mainFrame.revalidate();
    mainFrame.repaint();

    // Start sleep tracking
    startTime = LocalTime.now(); // Record the start time
}
LocalTime startTime ;
private void stopSleepTracking() {
    // Stop sleep tracking and calculate sleep duration
    LocalTime endTime = LocalTime.now(); // Get the current time as end time
    long durationSeconds = java.time.Duration.between(startTime, endTime).getSeconds();
    long hours = durationSeconds / 3600;
    long minutes = (durationSeconds % 3600) / 60;
    long seconds = durationSeconds % 60;

    // Display sleep duration
    JOptionPane.showMessageDialog(mainFrame, "Sleep Duration: " + hours + " hours " + minutes + " minutes " + seconds + " seconds");

    // Return to home frame
    openHomeFrame();
}

private void openBreathTimerFrame() {
    JFrame breathTimerFrame = new JFrame("Breath Timer");
    breathTimerFrame.setSize(400, 200);
    breathTimerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    breathTimerFrame.setLayout(new GridLayout(2, 1));

    JLabel instructionLabel = new JLabel("Select duration for your breath session:");
    instructionLabel.setHorizontalAlignment(SwingConstants.CENTER);

    JPanel buttonsPanel = new JPanel(new GridLayout(1, 3));
    JButton oneMinButton = new JButton("1 Min");
    JButton twoMinButton = new JButton("2 Min");
    JButton threeMinButton = new JButton("3 Min");

    buttonsPanel.add(oneMinButton);
    buttonsPanel.add(twoMinButton);
    buttonsPanel.add(threeMinButton);

    breathTimerFrame.add(instructionLabel);
    breathTimerFrame.add(buttonsPanel);

    breathTimerFrame.setVisible(true);

    // Action listeners for breath duration buttons
    oneMinButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            startBreathTimer(60);
            breathTimerFrame.dispose();
        }
    });

    twoMinButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            startBreathTimer(120);
            breathTimerFrame.dispose();
        }
    });

    threeMinButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            startBreathTimer(180);
            breathTimerFrame.dispose();
        }
    });
}

private void startBreathTimer(int durationSeconds) {
    JFrame breathTimerFrame = new JFrame("Breath Timer");
    breathTimerFrame.setSize(300, 150);
    breathTimerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    JLabel timerLabel = new JLabel();
    timerLabel.setFont(new Font("Arial", Font.BOLD, 24));
    timerLabel.setHorizontalAlignment(SwingConstants.CENTER);
    breathTimerFrame.add(timerLabel);

    JButton stopButton = new JButton("Stop");
    stopButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            breathTimerFrame.dispose();
        }
    });

    breathTimerFrame.add(stopButton, BorderLayout.SOUTH);

    breathTimerFrame.setVisible(true);

    // Start the timer
    Timer timer = new Timer(1000, new ActionListener() {
        int remainingSeconds = durationSeconds;

        @Override
        public void actionPerformed(ActionEvent e) {
            int minutes = remainingSeconds / 60;
            int seconds = remainingSeconds % 60;
            timerLabel.setText(String.format("%02d:%02d", minutes, seconds));
            remainingSeconds--;
            if (remainingSeconds < 0) {
                ((Timer) e.getSource()).stop();
                timerLabel.setText("Time's up!");
            }
        }
    });
    timer.start();
}


    private void setPanelBackground(JPanel panel) {
        panel.setOpaque(true);
        panel.setBackground(isDarkMode ? Color.BLACK : Color.WHITE);
    }

    private void setComponentBackground(Component component, Color color) {
        if (component instanceof Container) {
            Component[] components = ((Container) component).getComponents();
            for (Component comp : components) {
                setComponentBackground(comp, color);
            }
        }
        component.setBackground(color);
    }
    // New method to open the More Options frame
private void openMoreOptionsFrame() {
    JFrame moreOptionsFrame = new JFrame("More Options");
    moreOptionsFrame.setSize(400, 300);
    moreOptionsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    moreOptionsFrame.setLayout(new BorderLayout());

    // Panel for buttons
    JPanel buttonPanel = new JPanel(new GridLayout(3, 2));
    
    // Button for navigating back to the home page
    JButton backButton = new JButton("<-- Back to Home");
    backButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            openHomeFrame(); // Call method to open the home frame
            moreOptionsFrame.dispose(); // Close the More Options frame
        }
    });
    moreOptionsFrame.add(backButton, BorderLayout.NORTH);

    // Button for Sleep Tracking
    JButton sleepButton = new JButton("Sleep");
    sleepButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            openSleepTrackingFrame();
            moreOptionsFrame.dispose(); // Close the More Options frame after opening Sleep Tracking
        }
    });
    buttonPanel.add(sleepButton);

    // Button for Stories
    JButton storiesButton = new JButton("Stories");
    // Add ActionListener to open stories from YouTube or another source
    storiesButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            openStoriesVideos();
            moreOptionsFrame.dispose(); // Close the More Options frame after opening Stories videos
        }
    });
    buttonPanel.add(storiesButton);

    // Button for Breath
    JButton breathButton = new JButton("Breath");
    breathButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Implement action to open breath frame
            // For example:
            openBreathTimerFrame();
            moreOptionsFrame.dispose(); // Close the More Options frame after opening Breath frame
        }
    });
    buttonPanel.add(breathButton);

    // Button for Yoga & Stretching
    JButton yogaStretchingButton = new JButton("Yoga & Stretching");
    yogaStretchingButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Implement action to show yoga and stretching videos
            openYogaStretchingVideos();
            moreOptionsFrame.dispose(); // Close the More Options frame after opening Yoga & Stretching videos
        }
    });
    buttonPanel.add(yogaStretchingButton);

    JButton podcastsButton = new JButton("Podcasts");
    podcastsButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Implement action to show fitness, gym, and sleep podcasts
            openFitnessPodcasts();
            moreOptionsFrame.dispose(); // Close the More Options frame after opening Podcasts
        }
    });
    buttonPanel.add(podcastsButton);

    JButton changeProfileButton = new JButton("Change Profile");
    changeProfileButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            openChangeProfileFrame(); // Call method to open Change Profile frame
        }
    });
    buttonPanel.add(changeProfileButton);

    moreOptionsFrame.add(buttonPanel, BorderLayout.CENTER);

    // Add More Options frame to the main frame
    moreOptionsFrame.setVisible(true);
}

// Method to open the frame for changing profile information
private void openChangeProfileFrame() {
    JFrame changeProfileFrame = new JFrame("Change Profile");
    changeProfileFrame.setSize(400, 200);
    changeProfileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    changeProfileFrame.setLayout(new BorderLayout());

    // Panel for input fields
    JPanel inputPanel = new JPanel(new GridLayout(2, 2));
    inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    // Username label and text field
    JLabel usernameLabel = new JLabel("Username:");
    JTextField newUsernameField = new JTextField();
    inputPanel.add(usernameLabel);
    inputPanel.add(newUsernameField);

    // Password label and password field
    JLabel passwordLabel = new JLabel("Password:");
    JPasswordField newPasswordField = new JPasswordField();
    inputPanel.add(passwordLabel);
    inputPanel.add(newPasswordField);

    // Panel for buttons
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

    // Button to update profile information
    JButton updateButton = new JButton("Update Profile");
    updateButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Get the new username and password
            String newUsername = newUsernameField.getText();
            String newPassword = new String(newPasswordField.getPassword());
            
            // Update the profile information (you need to implement this part)
            // For demonstration purposes, let's just display the new username and password
            JOptionPane.showMessageDialog(changeProfileFrame, "New Username: " + newUsername + "\nNew Password: " + newPassword);

            // Clear the input fields after updating
            newUsernameField.setText("");
            newPasswordField.setText("");
          changeProfileFrame.dispose();
        }
    });
    buttonPanel.add(updateButton);

    // Add panels to the frame
    changeProfileFrame.add(inputPanel, BorderLayout.CENTER);
    changeProfileFrame.add(buttonPanel, BorderLayout.SOUTH);

    // Set the frame visible
    changeProfileFrame.setVisible(true);
}

private void openFitnessPodcasts() {
    // URL of fitness, gym, and sleep podcasts on YouTube
  
    String gymPodcastsUrl = "https://www.youtube.com/results?search_query=gym+podcasts";
 

    try {
 
        Desktop.getDesktop().browse(new URI(gymPodcastsUrl));
      
    } catch (IOException | URISyntaxException ex) {
        ex.printStackTrace();
        // Handle exception if unable to open web browser
    }
}
// Method to open Yoga and Stretching videos on YouTube
private void openYogaStretchingVideos() {
    // URL of Yoga and Stretching videos on YouTube
    String yogaStretchingUrl = "https://www.youtube.com/results?search_query=yoga+stretching";

    try {
        // Open the default web browser with the Yoga and Stretching videos URL
        Desktop.getDesktop().browse(new URI(yogaStretchingUrl));
    } catch (IOException | URISyntaxException ex) {
        ex.printStackTrace();
        // Handle exception if unable to open web browser
    }
}
private void openStoriesVideos() {
    // URL of Stories videos on YouTube
    String storiesUrl = "https://www.youtube.com/results?search_query=bedtime+stories";

    try {
        // Open the default web browser with the Stories videos URL
        Desktop.getDesktop().browse(new URI(storiesUrl));
    } catch (IOException | URISyntaxException ex) {
        ex.printStackTrace();
        // Handle exception if unable to open web browser
    }
}
    
}

